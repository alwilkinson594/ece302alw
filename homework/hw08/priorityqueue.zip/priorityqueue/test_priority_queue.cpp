#include "dynamic_array_list.h"
#include "sorted_list.h"
#include "priority_queue.h"

int main()
{
  typedef SortedList<int, DynamicArrayList<int> > SortedListType;
  typedef PriorityQueue<int, SortedListType>  PriorityQueueType;
  
  PriorityQueueType pq;
  int i=0; //Test whether correct, 0 for no, 1 for yes 
  //Test isEmpty
  if (pq.isEmpty()==true) i++;
  std::cout << i << std::endl;
  i=0; 
  //Test add
  pq.add(0); 
  if (pq.isEmpty()==false) i++; 
  std::cout << i << std::endl;
  i=0;
  //Test peek
  if (pq.peek()==0) i++;
  std::cout << i << std::endl; 
  i=0; 
  //Test remove 
  pq.remove(); 
  if (pq.isEmpty()==true) i++; 
  std::cout << i << std::endl; 
  i=0; 
  //Make sure add and remove function sorts correctly 
  for (int j=0; j<10; j++) pq.add(j); 
  if (pq.peek()==10) i++; 
  std::cout << i << std::endl; 
  i=0; 
  pq.add(15); 
  if (pq.peek()==15) i++; 
  std::cout << i << std::endl; 
  i=0; 
  pq.add(13); 
  if (pq.peek()==15) i++; 
  std::cout << i << std::endl; 
  i=0; 
  pq.remove(); 
  if (pq.peek()==13) i++; 
  std::cout << i << std::endl; 
  i=0; 
  
  return 0;
}
