#define CATCH_CONFIG_MAIN
#include "catch.hpp"

#include "bag.hpp"

// force template expansion
template class Bag<int>;

TEST_CASE("Empty Test", "[Bag]"){ //Tests that empty bag is created 
  REQUIRE(true);
}

TEST_CASE("Add Test", "[Bag]"){ //Tests size, contains, and add
	Bag<int> a;
	REQUIRE(a.getCurrentSize()==0); //Should be empty to start 
	REQUIRE(a.contains(5)==false); //Empty bags don't have a 5 in them 
	a.add(5); //Put in a 5
	REQUIRE(a.getCurrentSize()==1); //Should be 0+1=1 items now 
	REQUIRE(a.contains(5)==true); //Should be a 5 now 
} 

TEST_CASE("Remove Test", "[Bag]") { //Tests contains, add, and remove 
	Bag<int> b;
	b.add(3); //Put in 3
	REQUIRE(b.contains(3)==true); //3 now present 
	b.remove(3); //Take out the 3
	REQUIRE(b.contains(3)==false); //3 should not be there anymore 
}

TEST_CASE("Clear Test", "[Bag]") { //Tests clear and frequency 
	Bag<int> c;
	REQUIRE(c.getFrequencyOf(7)==0); //Should be empty to start, so no 7
	c.add(7); //Add 4 7's
	c.add(7);
	c.add(7);
	c.add(7);
	REQUIRE(c.getFrequencyOf(7)==4); //Make sure you get 4 7's 
	c.clear(); //Clear the bag 
	REQUIRE(c.getFrequencyOf(7)==0); //Make sure there are no more 7's
}


