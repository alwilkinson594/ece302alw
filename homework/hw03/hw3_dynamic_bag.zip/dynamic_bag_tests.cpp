#define CATCH_CONFIG_MAIN
#include "catch.hpp"

#include "dynamic_bag.hpp"

// force template expansion for ints
template class DynamicBag<int>;

TEST_CASE("Calling all public members", "[DynamicBag]"){
  DynamicBag<int> b;

  b.add(0);
  b.remove(0);
  b.isEmpty();
  b.getCurrentSize();
  b.clear();
  b.getFrequencyOf(0);
  b.contains(0);
}

TEST_CASE("Test add function","[DynamicBag]") {
	DynamicBag<int> a;
	REQUIRE(a.contains(1)==false);
	a.add(1);
	REQUIRE(a.contains(1)==true);
}

TEST_CASE("Test remove function","[DynamicBag]") {
	DynamicBag<int> c;
	c.add(3);
	REQUIRE(c.contains(3)==true);
	c.remove(3);
	REQUIRE(c.contains(3)==false);
} 

TEST_CASE("Test isEmpty function","[DynamicBag]") {
	DynamicBag<int> d;
	REQUIRE(d.isEmpty()==true);
	d.add(2);
	REQUIRE(d.isEmpty()==false);
} 

TEST_CASE("Test getCurrentSize function","[DynamicBag]") {
	DynamicBag<int> e;
	REQUIRE(e.getCurrentSize()==0);
	e.add(2);
	e.add(1);
	e.add(5);
	e.add(91);
	REQUIRE(e.getCurrentSize()==4);
} 

TEST_CASE("Test clear function","[DynamicBag]") {
	DynamicBag<int> f;
	f.add(4);
	f.add(7);
	REQUIRE(f.isEmpty()==false);
	f.clear();
	REQUIRE(f.isEmpty()==true);
} 

TEST_CASE("Test getFrequencyOf function","[DynamicBag]") {
	DynamicBag<int> g;
	REQUIRE(g.getFrequencyOf(6)==0);
	g.add(6);
	g.add(6);
	g.add(3);
	REQUIRE(g.getFrequencyOf(6)==2);
} 

TEST_CASE("Test contains function","[DynamicBag]") {
	DynamicBag<int> h;
	REQUIRE(h.contains(3)==false);
	h.add(3);
	REQUIRE(h.contains(3)==true);
} 

TEST_CASE("Test with more than cap","[DynamicBag]") {
	DynamicBag<int> i;
	i.add(1);
	i.add(2);
	i.add(3);
	i.add(4);
	i.add(5);
	i.add(1);
	i.add(2);
	i.add(3);
	i.add(4);
	i.add(5);
	i.add(1);
	i.add(2);
	i.add(3);
	i.add(4);
	i.add(5);
	REQUIRE(i.getCurrentSize()==15);
	REQUIRE(i.getFrequencyOf(3)==3);
	i.remove(5);
	i.remove(5);
	i.remove(5);
	i.remove(4);
	i.remove(4);
	i.remove(4);
	REQUIRE(i.getCurrentSize()==9);
} 


