#define CATCH_CONFIG_MAIN
#include "catch.hpp"

#include "fancyPower.hpp"

// write your test cases here
TEST_CASE("Test case", "fancyPower"){

  REQUIRE(true);
  
}

TEST_CASE("Test even n", "fancyPower") { //Test an even power 
	REQUIRE(fancyPower(4,2)==16); 
	REQUIRE(fancyPower(10,3)==59049);//Test a big number
	REQUIRE(fancyPower(2,7)==49);
} 

TEST_CASE("Test odd n", "fancyPower") { //Test an odd power 
	REQUIRE(fancyPower(3,3)==27);
	REQUIRE(fancyPower(4,1)==1); 
	REQUIRE(fancyPower(9,2)==512);//Test a big number
}
