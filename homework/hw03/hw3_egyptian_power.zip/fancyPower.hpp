#ifndef FANCYPOWER_HPP
#define FANCYPOWER_HPP

int fancyPower(int n, int m)
{
	int val;
	if (n==0) { //Base case 
		val=1; //x^0=1 no matter what x is 
	} 
	else { //Value is previous product multiplied by m
		val=m*fancyPower(n-1,m);
	} 
	return val;
}

#endif
