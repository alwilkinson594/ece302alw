#include <iostream>
using std::cout;
using std::endl;

#include "BinaryTree.h"

typedef std::string ItemType;
typedef void (*FunctionType)(ItemType& anItem);

void PrintNode(ItemType& i) { cout << i << endl; };

int main(int argc, char** argv)
{
    BinaryTree<ItemType, FunctionType> T1("B");
    BinaryTree<ItemType, FunctionType> T2("C");

    BinaryTree<ItemType, FunctionType> T3("A");
    T3.attachLeftSubtree(T1);
    T3.attachRightSubtree(T2);
    std::cout << "\nPostorder: \n"; 
    T3.postorderTraverse(&PrintNode);
    std::cout << "\nPreorder: \n"; 
    T3.preorderTraverse(&PrintNode);
    std::cout << "\nInorder: \n"; 
    T3.inorderTraverse(&PrintNode);

    // now T1 and T2 are no longer trees, but empty objects 
    
    
    //Make a larger tree with 7 nodes 
    BinaryTree<ItemType, FunctionType> t0("0"); 
    BinaryTree<ItemType, FunctionType> t1("1"); 
    BinaryTree<ItemType, FunctionType> t2("2"); 
    BinaryTree<ItemType, FunctionType> t3("3"); 
    BinaryTree<ItemType, FunctionType> t4("4");  
    BinaryTree<ItemType, FunctionType> t5("5"); 
    BinaryTree<ItemType, FunctionType> t6("6"); 
    //Create left subtree 
    t1.attachLeftSubtree(t3);
    t1.attachRightSubtree(t4); 
    cout << "\n\nTesting larger tree:\n"; 
    cout << "\nInorder of 1 as root, 3 as left sub, 4 as right sub should give 314:\n";  
    t1.inorderTraverse(&PrintNode); 
    //Create right subtree 
    t2.attachLeftSubtree(t5);
    t2.attachRightSubtree(t6); 
    cout << "\nInorder of 2 as root, 5 as left sub, 6 as right sub should give 526:\n"; 
    t2.inorderTraverse(&PrintNode); 
    //Put whole tree together 
    t0.attachLeftSubtree(t1);
    t0.attachRightSubtree(t2); 
    cout << "\nInorder of 0 as root, 1 as left sub, 2 as right sub should give 3140526:\n";
    t0.inorderTraverse(&PrintNode); 
    cout << "\nPostorder of same, should give 3415620:\n"; 
    t0.postorderTraverse(&PrintNode); 
    cout << "\nPreorder of same, should give 0134256:\n"; 
    t0.preorderTraverse(&PrintNode); 
         
    return 0;
};
