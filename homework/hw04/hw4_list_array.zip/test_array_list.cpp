#define CATCH_CONFIG_MAIN
#include "catch.hpp"

#include "array_list.hpp"

//force class expansion
template class ArrayList<int>;

TEST_CASE( "Test", "[ArrayList]" ) {

  ArrayList<int> list;
}

TEST_CASE("Insert test", "[ArrayList]") {
	ArrayList<int> a; 
	REQUIRE(a.isEmpty()==true); 
	REQUIRE(a.getLength()==0);
	a.insert(1,5); 
	REQUIRE(a.isEmpty()==false);
	REQUIRE(a.getLength()==1);
	REQUIRE(a.getEntry(1)==5); 
	a.insert(2,1);
	a.insert(3,1);
	a.insert(4,2);
	a.insert(5,6);
	a.insert(6,2);
	a.insert(7,9);
	a.insert(8,23);
	a.insert(9,23);
	a.insert(10,6);
	a.insert(11,5);
	REQUIRE(a.getLength()==11);
	REQUIRE(a.getEntry(10)==6);
	REQUIRE(a.getEntry(11)==5); 
	
	REQUIRE(a.insert(2,4)==true);
	REQUIRE(a.insert(23,8)==false);
} 

TEST_CASE("Remove test", "[ArrayList]") {
	ArrayList<int> b; 
	b.insert(1,5); 
	b.insert(2,1);
	b.insert(3,1);
	b.insert(4,2);
	b.insert(5,6);
	b.insert(6,2);
	b.insert(7,9);
	b.insert(8,23);
	b.insert(9,23);
	b.insert(10,6);
	b.insert(11,5);
	REQUIRE(b.getLength()==11);
	REQUIRE(b.getEntry(9)==23);
	REQUIRE(b.getEntry(10)==6);
	REQUIRE(b.getEntry(11)==5); 
	b.remove(10); 
	REQUIRE(b.getLength()==10); 
	REQUIRE(b.getEntry(10)==5);
	
	REQUIRE(b.remove(6)==true);
	REQUIRE(b.remove(31)==false);
}

TEST_CASE("Clear test", "[ArrayList]") {
	ArrayList<int> c; 
	c.insert(1,5); 
	c.insert(2,1);
	c.insert(3,1);
	c.insert(4,2);
	c.insert(5,6);
	c.insert(6,2);
	REQUIRE(c.getLength()==6);
	REQUIRE(c.isEmpty()==false);
	c.clear();
	REQUIRE(c.getLength()==0);
	REQUIRE(c.isEmpty()==true);
} 

TEST_CASE("Set entry test", "[ArrayList]") {
	ArrayList<int> d; 
	d.insert(1,5); 
	d.insert(2,1);
	d.insert(3,1);
	d.insert(4,2);
	d.insert(5,6);
	d.insert(6,2);
	REQUIRE(d.getEntry(4)==2); 
	d.setEntry(4,10);
	REQUIRE(d.getEntry(4)==10); 
} 

