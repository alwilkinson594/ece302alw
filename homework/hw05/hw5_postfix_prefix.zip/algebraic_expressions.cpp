#include <string>
using std::string;

#include <iostream>

#include <cctype> // for isalpha

#include "algebraic_expressions.hpp"

bool isoperator(char ch) {
  return ((ch == '+') || (ch == '-') || (ch == '/') || (ch == '*'));
}

int endPost(string s, int last) {
  int first = 0;

  if ((first > last)) {
    return -1;
  }

  char ch = s[last];
  if (isalpha(ch)) {
    return last;
  } else {
    if (isoperator(ch)) {
      int lastEnd = endPost(s, last - 1);
      if (lastEnd > -1) {
        return endPost(s, lastEnd - 1);
      } else {
        return -1;
      }
    } else {
      return -1;
    }
  }
}

bool isPost(string s) {
  int firstChar = endPost(s, s.size() - 1);

  return (firstChar == 0);
}

//Convert from postfix to prefix 
void convert(string &postfix, string &prefix) {
	//Get length of string 
	int num=postfix.length(); 
	
	//Make stacks 
  std::string ops[num]; 
  int opNum=0;
  std::string vars[num];
  int varNum=0;
  
  for (int i=0; i<num; i++) { //For each term loop
  	if (isoperator(postfix[i])==true) { //For operators 
  		//Get variables they connect 
  		std::string ex1=vars[varNum-1]; 
  		vars[varNum-1]="";
  		varNum--; 
  		std::string ex2=vars[varNum-1]; 
  		vars[varNum-1]="";
  		varNum--; 
  		//Combine into new string 
  		std::string ex=postfix[i]+ex2+ex1; 
  		//Add combination to stack 
  		vars[varNum]=ex; 
  		varNum++;  
  	} 
  	else { //For variables 
  		vars[varNum]=postfix[i]; 
  		varNum++; 
  	} 
  } 
  //Set final expression
  prefix=vars[varNum-1]; 
}
