#include <cassert>

#include "dynamic_array_list.h"
#include "heap_priority_queue.h"

int main()
{
  HeapPriorityQueue<int>  pq;
  assert(pq.isEmpty());
  
  pq.add(25);
  assert(!pq.isEmpty());
  assert(pq.peek() == 25);

  pq.add(1);
  assert(pq.peek() == 25);

  pq.add(78);
  assert(pq.peek() == 78);

  pq.remove();
  pq.remove();
  pq.remove();
  assert(pq.isEmpty());
  
  
  //End of given tests 
  
  //Test creation with multiple types 
  HeapPriorityQueue<std::string> qString; 
  if (qString.isEmpty()==true) std::cout << "\nEmpty string queue created successfully\n";  
  else std::cout << "\nFailed to create empty string queue\n"; 
  
  HeapPriorityQueue<int> qInt; 
  if (qInt.isEmpty()==true) std::cout << "\nEmpty int queue created successfully\n"; 
  else std::cout << "\nFailed to create empty int queue\n"; 
  
  //Test adding with multiple types 
  qString.add("A"); 
  if (qString.peek()=="A") { 
  	qString.add("C");
  	qString.add("B");  
  	if (qString.peek()=="C") std::cout << "\nAdded strings correctly\n"; 
  	else std::cout << "\nFailed to add strings correctly\n"; 
  } 
  else std::cout <<"\nFailed to add a string\n"; 
  
  qInt.add(1); 
  if (qInt.peek()==1) { 
  	qInt.add(3); 
  	qInt.add(2); 
  	if (qInt.peek()==3) std::cout << "\nAdded ints correctly\n"; 
  	else std::cout << "\nFailed to add ints correctly\n"; 
  } 
  else std::cout << "\nFailed to add an int\n"; 
  
  //Test removing with multiple types 
  qString.remove(); 
  if (qString.peek()=="B") { 
  	qString.remove(); 
  	if (qString.peek()=="A") { 
  		qString.remove(); 
  		if (qString.isEmpty()==true) std::cout << "\nRemoved strings correctly\n"; 
  		else std::cout << "\nFailed to remove strings correctly\n"; 
  	} 
  	else std::cout << "\nFailed to remove strings correctly\n"; 
  } 
  else std::cout << "\nFailed to remove strings correctly\n"; 
  
  qInt.remove(); 
  if (qInt.peek()==2) { 
  	qInt.remove(); 
  	if (qInt.peek()==1) { 
  		qInt.remove(); 
  		if (qInt.isEmpty()==true) std::cout << "\nRemoved ints correctly\n"; 
  		else std::cout << "\nFailed to remove ints correctly\n"; 
  	} 
  	else std::cout << "\nFailed to remove ints correctly\n"; 
  } 
  else std::cout << "\nFailed to remove ints correctly\n"; 
  
  return 0;
}
