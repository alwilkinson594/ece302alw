#include <iostream> 
#include "image.h" 
#include "deque.hpp"

int main(int argc, char *argv[]) {
	//Need one total argument for queue 
	struct spot {
		//Location of spot 
		int row; 
		int col;
		//Has it been visited 
		bool visL; 
		bool visR; 
		bool visU; 
		bool visD; 
	}; 
	
	//Read picture 
	Image<Pixel> maze = readFromFile(argv[1]); 
	int rowNum=maze.height(); 
	int colNum=maze.width();
	
	//Initialize a deque and spot 
	Deque<spot> visits; 
	spot init; 
	init.visL=false; 
	init.visR=false; 
	init.visU=false; 
	init.visD=false; 
	
	//Find the red dot 
	int initRow, initCol; 
	for (int i=0; i<rowNum; i++) {
		for (int j=0; j<colNum; j++) { 
			if (maze(i,j)==RED) { 
				init.row=i; 
				init.col=j; 
			} 
		} 
	} 
	
	//Add start point to deque 
	visits.pushFront(init); 
	bool suc=false; 
	
	//Until the solution is found or there are no moves left, search 
	while (visits.isEmpty()==false && suc==false) { 
		spot curr=visits.front(); 
		//If at exit - success 
		if (curr.row==0 || curr.row==rowNum-1 || curr.col==0 || curr.col==colNum-1) { 
			suc=true;  
			maze(curr.row, curr.col) = GREEN; 
			std::cout << "Solution Found\n"; 
			return EXIT_SUCCESS; 
		}
		 
		//If possible to move left and haven't already done so 
		else if (curr.col>0 && maze(curr.row, curr.col-1)==WHITE && curr.visL==false) { 
			//Mark left as visited 
			curr.visL=true; 
			//Add new iinformation to queue 
			spot l;  
			maze(curr.row, curr.col-1)=RED; 
			l.row=curr.row; 
			l.col=curr.col-1; 
			l.visR=true; 
			l.visL=false; 
			l.visU=false; 
			l.visD=false; 
			visits.pushFront(l); 
		} 
		
		//If possible to move right and haven't already done so 
		else if (curr.col<colNum-1 && maze(curr.row, curr.col+1)==WHITE && curr.visR==false) { 
			//Mark right as visited 
			curr.visR=true; 
			//Add new information to the queue 
			spot r;
			maze(curr.row, curr.col+1)=RED;  
			r.row=curr.row; 
			r.col=curr.col+1; 
			r.visR=false; 
			r.visL=true; 
			r.visU=false; 
			r.visD=false; 
			visits.pushFront(r); 
		} 
		
		//If possible to move up and haven't already done so 
		else if (curr.row>0 && maze(curr.row-1, curr.col)==WHITE && curr.visU==false) { 
			curr.visU=true; 
			spot u; 
			maze(curr.row-1, curr.col)=RED; 
			u.row=curr.row-1; 
			u.col=curr.col; 
			u.visR=false; 
			u.visL=false; 
			u.visU=false; 
			u.visD=true; 
			visits.pushFront(u); 
		} 
		
		//If possible to move down and haven't already done so 
		else if (curr.row<rowNum-1 && maze(curr.row+1, curr.col)==WHITE && curr.visD==false) { 
			curr.visD=false; 
			spot d; 
			maze(curr.row+1, curr.col)=RED; 
			d.row=curr.row+1; 
			d.col=curr.col; 
			d.visR=false; 
			d.visL=false; 
			d.visU=true; 
			d.visD=false; 
		} 
		
		//If stuck, backtrack 
		else {
			maze(curr.row, curr.col)=RED; 
			visits.popFront(); 
		} 
	} //End of searching algorithm 
	
	//Fail results: 
	std::cout << "Solution Not Found\n"; 
	return EXIT_FAILURE; 	
} 

/*
States: 
	previousRow=(r-1, c) 
	nextRow=(r+1, c) 
	previousColumn=(r, c-1) 
	nextColumn=(r, c+1) 
search in that order 

Colors: 
	WHITE = open 
	BLACK = wall 
	RED = initial state 
	GREEN = goal once found 
change start to green if it is the goal 
*/ 
