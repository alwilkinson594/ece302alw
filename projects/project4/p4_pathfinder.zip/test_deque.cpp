#define CATCH_CONFIG_MAIN
#include "catch.hpp"

#include "deque.hpp"

TEST_CASE( "Tests", "[deque]" ) {}

TEST_CASE( "Test constructors", "[deque]" ) {
	Deque<int> a; 
	REQUIRE(a.isEmpty()==true); 
	a.pushBack(5); 
	REQUIRE(a.isEmpty()==false); 
	
	Deque<int> a1;
	REQUIRE(a1.isEmpty()==true); 
	a.pushFront(12); 
	REQUIRE(a.isEmpty()==false);  
} 

TEST_CASE( "Test operations on front", "[deque]" ) {
	Deque<int> b; 
	REQUIRE(b.isEmpty()==true); 
	b.pushFront(1); 
	REQUIRE(b.isEmpty()==false); 
	b.pushFront(2); 
	b.pushFront(3);
	b.pushFront(4); 
	b.pushFront(5); 
	REQUIRE(b.front()==5); 
	b.popFront(); 
	REQUIRE(b.front()==4); 
	b.popFront(); 
	REQUIRE(b.front()==3); 
	b.popFront(); 
	REQUIRE(b.front()==2); 
	b.popFront(); 
	REQUIRE(b.front()==1); 
	b.popFront(); 
	REQUIRE(b.isEmpty()==true); 
} 

TEST_CASE( "Test operations on back", "[deque]" ) {
	Deque<int> c; 
	REQUIRE(c.isEmpty()==true); 
	c.pushBack(1); 
	REQUIRE(c.isEmpty()==false); 
	c.pushBack(2); 
	c.pushBack(3);
	c.pushBack(4); 
	c.pushBack(5); 
	REQUIRE(c.back()==5); 
	c.popBack(); 
	REQUIRE(c.back()==4); 
	c.popBack(); 
	REQUIRE(c.back()==3); 
	c.popBack(); 
	REQUIRE(c.back()==2); 
	c.popBack(); 
	REQUIRE(c.back()==1); 
	c.popBack(); 
	REQUIRE(c.isEmpty()==true); 
} 

TEST_CASE( "Test a mix of front and back operations", "[deque]" ) {
	Deque<int> d; 
	REQUIRE(d.isEmpty()==true); 
	d.pushFront(1); 
	d.pushBack(5); 
	REQUIRE(d.front()==1); 
	REQUIRE(d.back()==5); 
	d.pushFront(2); 
	REQUIRE(d.front()==2); 
	d.popBack(); 
	REQUIRE(d.back()==1); 
	d.popBack(); 
	REQUIRE(d.back()==2); 
	d.popBack(); 
	REQUIRE(d.isEmpty()==true); 
} 

