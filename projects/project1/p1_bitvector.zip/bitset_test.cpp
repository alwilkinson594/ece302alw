#define CATCH_CONFIG_MAIN
#define CATCH_CONFIG_COLOUR_NONE
#include "catch.hpp"

#include "bitset.hpp"

// THIS IS JUST AN EXAMPLE
// There should be at least one test per Bitset method

//Given test case - default constructor makes a valid bitset 
TEST_CASE( "Test bitset construction", "[bitset]" ) { 
  Bitset b;  
  REQUIRE(b.size() == 8);
  REQUIRE(b.good());
}

//Second constructor makes a valid bitset 
TEST_CASE("Test bitset construction with number", "[bitset]" ) {
	Bitset a(16); //Make a bitset with the number constructor 
	
	//Make sure it is the right size and valid 
	REQUIRE(a.size() == 16); 
	REQUIRE(a.good()); 
	
	//Make sure it is filled with all 0s
	REQUIRE(a.test(0)==false);
  REQUIRE(a.test(1)==false);
  REQUIRE(a.test(2)==false);
  REQUIRE(a.test(3)==false);
  REQUIRE(a.test(4)==false);
  REQUIRE(a.test(5)==false);
  REQUIRE(a.test(6)==false);
  REQUIRE(a.test(7)==false);
  REQUIRE(a.test(8)==false);
  REQUIRE(a.test(9)==false);
  REQUIRE(a.test(10)==false);
  REQUIRE(a.test(11)==false);
  REQUIRE(a.test(12)==false);
  REQUIRE(a.test(13)==false);
  REQUIRE(a.test(14)==false);
  REQUIRE(a.test(15)==false);
}

//Test third constructor 
TEST_CASE( "Test bitset construction with string", "[bitset]" ) {
	Bitset c("0011"); //Make a bitset with a string 
	//Make sure the bitset is the right size and valid
	REQUIRE(c.size()==4); 
	REQUIRE(c.good()==true); 
	//Make sure all the digits are right - indexing from the right to left 
	REQUIRE(c.test(0)==true);
	REQUIRE(c.test(1)==true);
	REQUIRE(c.test(2)==false);
	REQUIRE(c.test(3)==false);
	REQUIRE(c.asString()=="0011"); 
} 

//Test the destructor 
TEST_CASE( "Test destructor", "[bitset]" ) { 
	Bitset d; //Make a bitset 
	d.~Bitset(); //Call destructor on bitset 
} 

//Test the size function 
TEST_CASE( "Test size", "[bitset]" ) {
	Bitset e1; //Make a bitset to test and test it 
	REQUIRE(e1.size()==8); 
	
	Bitset e2(9); //Make a second bitset to test and test it 
	REQUIRE(e2.size()==9); 
	
	Bitset e3(22); //Make a third bitset to test and test it
	REQUIRE (e3.size()==22); 
	
	Bitset e4(64); //Make a fourth bitset to test and test it 
	REQUIRE (e4.size()==64); 
} 

//Test the good function 
TEST_CASE( "Test good", "[bitset]" ) {
	Bitset f1("000111"); //Make a valid bitset to test and test it 
	REQUIRE(f1.good()==true); 
	
	Bitset f2("00011a"); //Make an invalid bitset to test and test it 
	REQUIRE(f2.good()==false);
} 

//Test the set function 
TEST_CASE( "Test set", "[bitset]" ) {
	Bitset g(4); //Make a bitset to use 
	g.set(1); //Set two of the values 
	g.set(3); 
	REQUIRE(g.good()==true); //Make sure the bitset is still valid  
	REQUIRE(g.test(0)==false); //Make sure the right values were set 
	REQUIRE(g.test(1)==true);
	REQUIRE(g.test(2)==false);
	REQUIRE(g.test(3)==true);
} 

//Test the reset function 
TEST_CASE( "Test reset", "[bitset]" ) {
	Bitset h("1111"); //Make a bitset to use 
	h.reset(1); //Reset 2 values 
	h.reset(3); 
	REQUIRE(h.good()==true); //Make sure the bitset is still valid 
	REQUIRE(h.test(0)==true); //Make sure the right values were reset 
	REQUIRE(h.test(1)==false);
	REQUIRE(h.test(2)==true);
	REQUIRE(h.test(3)==false);
} 

//Test the toggle function 
TEST_CASE( "Test toggle", "[bitset]" ) {
	Bitset i(2); //Make a bitset to test 
	REQUIRE(i.test(0)==false);
	REQUIRE(i.test(1)==false);
	i.toggle(0); //Toggle one bit and make sure the right one is changed 
	REQUIRE(i.test(0)==true);
	REQUIRE(i.test(1)==false); 
	
	//Toggle both to make sure they both can be toggled and it can go both ways 
	i.toggle(0); 
	i.toggle(1);
	REQUIRE(i.test(0)==false);
	REQUIRE(i.test(1)==true);
} 

TEST_CASE( "Test test", "[bitset]" ) {
	//Test 0s
	Bitset j1(2); 
	REQUIRE(j1.test(0)==false); 
	REQUIRE(j1.test(1)==false); 
	REQUIRE(j1.good()==true);
	
	//Test 1s
	Bitset j2("11"); 
	REQUIRE(j2.test(0)==true);
	REQUIRE(j2.test(1)==true); 
	REQUIRE(j2.good()==true);
	
	//Test a mix of 0/1 
	Bitset j3("01"); 
	REQUIRE(j3.test(0)==true);
	REQUIRE(j3.test(1)==false);
	REQUIRE(j3.good()==true);
	//Test what doesn't exist-invalid case
	REQUIRE(j3.test(3)==false); 
	REQUIRE(j3.good()==false); 
} 

TEST_CASE( "Test asString", "[bitset]" ) {
	//Make a bitset to test 
	Bitset k(2); 
	REQUIRE(k.asString()=="00"); 
	//Test with a 1
	k.set(0); 
	REQUIRE(k.asString()=="01");  
	
	//Test something longer 
	Bitset k1(25); 
	REQUIRE(k1.asString()=="0000000000000000000000000"); 	
	k1.set(0);
	k1.set(1);
	k1.set(2);
	k1.set(3);
	k1.set(4);
	//Test end 
	REQUIRE(k1.asString()=="0000000000000000000011111");
	k1.set(20);
	k1.set(21);
	k1.set(22);
	k1.set(23);
	k1.set(24);
	//Test beginning 
	REQUIRE(k1.asString()=="1111100000000000000011111");
	k1.set(12);
	k1.set(13);
	k1.set(14);
	k1.set(15);
	k1.set(16);
	//Test middle
	REQUIRE(k1.asString()=="1111100011111000000011111");
	
	Bitset l("1010");
	REQUIRE(l.good()==true);
	REQUIRE(l.test(0)==false);
	REQUIRE(l.test(1)==true);
	REQUIRE(l.test(2)==false);
	REQUIRE(l.test(3)==true);
	REQUIRE(l.asString()=="1010");
	//One more 
	Bitset k2("101010101010101");
	REQUIRE(k2.asString()=="101010101010101");
} 

