#ifndef BITSET_HPP
#define BITSET_HPP

#include <string>
#include <iostream> 
class Bitset{
public:

  // Default constructor, create a bitset with 8 bits set to 0
  Bitset();

  // Other constructor, create a bitset with the user-defined number of bits set to 0
  Bitset(intmax_t size);

  // Other constructor, create a bitset from a string of bits given 
  Bitset(const std::string & value);

  // Destructor, deallocate the memory space used for the bitset 
  ~Bitset();

  Bitset(const Bitset & ) = delete;
  Bitset & operator=(const Bitset &) = delete;

  // Function to return the size of the bitset 
  intmax_t size() const;

  // Function to determine if the bitset is valid 
  bool good() const;

  // Function to set a given bit to 1, unless it doesn't exist in the bitset 
  void set(intmax_t index);

  // Function to set a given bit to 0, unless it doesn't exist in the bitset 
  void reset(intmax_t index);

  // Function to change a given bit to its opposite (0/1) unless it doesn't exist in the bitset 
  void toggle(intmax_t index);

  // Function to test if the nth bit is set, unless there is no nth bit 
  bool test(intmax_t index);

  // Function to return the bitset as a string 
  std::string asString() const;

private:
	uint8_t* bitset; //Pointer to the bitset, must be pointer to be able to dynamically allocate space
	bool valid; //Variable to determine if a class instance is valid 
	int num; //Variable to hold the number of bits
};

#endif
