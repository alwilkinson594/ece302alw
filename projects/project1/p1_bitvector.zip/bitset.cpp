#include "bitset.hpp"


//Constructors and Destructors: 

// Default constructor, create a bitset with 8 bits set to 0
Bitset::Bitset() {
	bitset=new uint8_t; //Make the dynamically allocated array 
	num=8;
	bitset=0; //Zero all values in the array 
	valid=true;
} //End constructor 

// Other constructor, create a bitset with the user-defined number of bits set to 0
Bitset::Bitset(intmax_t size) {
	num = size;
	int j = (size+7)/8; 
	bitset=new uint8_t[j];//Make the dynamically allocated array
	for (int i=0; i<j; i++) bitset[i]=0; //Zero all values in the array 
	if (size>0) valid=true; 
	else valid=false;
} //End constructor 

// Other constructor, create a bitset from a string of bits given 
Bitset::Bitset(const std::string & value) {
	int size = value.length(); //Get length of the string and set to num
	num=size;
	
	valid=true;
	
	int s=(size+7)/8; //Get number of bytes needed 
	bitset=new uint8_t[s];
	
	int left=num%8; //Get number of bits in leftmost byte 
	if (left==0) left=8;

  bitset[s-1]=0;
  	
	for (int i=0; i<left; i++) { //For the leftover bits in the first byte
		if (value[i]=='1') bitset[s-1] |= (1 << (left-i-1)); 
		else if (value[i]=='0') bitset[s-1] &= ~(1 << (left-i-1));
		else valid=false; 
	} 
	
	for (int i=((num-left)/8-1); i>=0; i--) { //For each byte
	  bitset[s-i-2]=0; 
		for (int j=0; j<8; j++) { //For each bit within a byte 
			int index=8*(s-i-2) + left + j; //Get the index based on bytes and leftover bits 
			if (value[index]=='1') { //If 1
				bitset[i] |= (1 << (7-j));
			}
			else if (value[index]=='0') { //If 0
				bitset[i] &= ~(1 << (7-j));
			} 
			else valid=false;
		}
	} 	
} //End function 

// Destructor, deallocate the memory space used for the bitset 
Bitset::~Bitset() {
	delete [] bitset; //Delete the array values 
	bitset=NULL; //Reset the pointer to NULL to avoid leaks 
} //End destructor 



//Other Bitset functions 

// Function to return the size of the bitset 
intmax_t Bitset::size() const {
	return num; //Send the number of bits in the bitset
} //End function 

// Function to determine if the bitset is valid 
bool Bitset::good() const {
	return valid; //Return whether it is valid or not 
} //End function 

// Function to set a given bit to 1, unless it doesn't exist in the bitset 
void Bitset::set(intmax_t index) {
	if (index<num) { //Set the value at the index if it exists 
		int i=index/8; 
		int j=index%8; 
		bitset[i] |= (1 << j);
	}
	else valid=false; //If the index doesn't exist, it is invalid 
} //End function 

// Function to set a given bit to 0, unless it doesn't exist in the bitset 
void Bitset::reset(intmax_t index) {
	if (index<num) { //Set the value at the index if it exists 
		int i=index/8; 
		int j=index%8;
		bitset[i] &= ~(1 << j);
	} 
	else valid=false; //If the index doesn't exist, it is invalid 
} //End function 

// Function to change a given bit to its opposite (0/1) unless it doesn't exist in the bitset 
void Bitset::toggle(intmax_t index) {
	if (index<num) { //Set the value at the index if it exists 
		int i=index/8; 
		int j=index%8;
		bitset[i] ^= 1UL << j; 
	}
	else valid=false; //Invalid if the index does not exist 
} //End function 

// Function to test if the nth bit is set, unless there is no nth bit 
bool Bitset::test(intmax_t index) {
	bool val=false; //Bool to hold value 
	
	int i = index/8;
	int j = index%8; 
	
	if (index<num) { //If the index exists, check whether it is set or not
		val = (bitset[i] >> j) & 1U;
	}  
	else { //Not set if it doesn't exist 
		valid=false; //If not exist, invalid
	} //End else
	return val; //Return the value of set 
} //End function 

// Function to return the bitset as a string 
std::string Bitset::asString() const {
	std::string set; //New string to hold value 
	int b = (num+7)/8; 
	for (int i=b-1; i>-1; i--) { //For each byte 
		for (int j=7; j>-1; j--) { //For each bit, left to right
			int x=8*i+j; //Calculate index
			if (x>=num) {} //If out of range, ignore it
			else {
				int a = (bitset[i] >> j) & 1UL;
				if (a==1) set+="1";
				else if (a==0) set+="0"; 
			} 
		}
	}
	return set;
} 

