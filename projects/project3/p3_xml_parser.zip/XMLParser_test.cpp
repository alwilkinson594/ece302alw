#define CATCH_CONFIG_MAIN
#define CATCH_CONFIG_COLOUR_NONE
#include <iostream>
#include "catch.hpp"
#include "XMLParser.cpp"

using namespace std;

TEST_CASE( "Test Bag add", "[XMLParser]" )
{
	   INFO("Hint: testing Bag add()");
		// Create a Bag to hold ints
		Bag<int> intBag;
		int testSize = 2;
		int bagSize;
		bool success;
		for (int i=0; i<testSize; i++) {
			success = intBag.add(i);
			REQUIRE(success);
			bagSize = intBag.size();
			success = (bagSize == (i+1));
			REQUIRE(success);
		}
}

//Stack tests: push, peek, pop 
TEST_CASE( "Test Stack push", "[XMLParser]" )
{
	   INFO("Hint: testing Stack push()");
		// Create a Stack to hold ints
		Stack<int> intStack;
		int testSize = 3;
		int stackSize;
		bool success;
		for (int i=0; i<testSize; i++) {
			success = intStack.push(i);
			REQUIRE(success);
			stackSize = intStack.size();
			success = (stackSize == (i+1));
			REQUIRE(success);
		}
} 

TEST_CASE( "Test Stack peek", "[XMLParser]" ) {
	INFO("Hint: testing Stack peek()"); 
	Stack<int> a; 
	a.push(3); 
	REQUIRE(a.peek()==3); 
	a.push(5); 
	REQUIRE(a.peek()==5); 
} 

TEST_CASE( "Test Stack pop", "[XMLParser]" ) { 
	INFO("Hint: testing Stack pop()"); 
	Stack<int> b; 
	b.push(8); 
	b.push(6); 
	REQUIRE(b.size()==2); 
	REQUIRE(b.peek()==6); 
	REQUIRE(b.pop()==true); 
	REQUIRE(b.size()==1); 
	REQUIRE(b.peek()==8); 
} 


//Parsing tests 

TEST_CASE( "Test XMLParser tokenizeInputString", "[XMLParser]" )
{
	   INFO("Hint: tokenize single element test of XMLParse");
		// Create an instance of XMLParse
		XMLParser myXMLParser;
		string testString = "<test>stuff</test>";
		bool success;
		success = myXMLParser.tokenizeInputString(testString);
		REQUIRE(success);
} 

TEST_CASE( "Test XMLParser parseTokenizedInput", "[XMLParser]" ) { 
	XMLParser c; 
	string testString="<tests n>aodifa<candy>asoifj<emp/></candy>adfj<?Jadoif?></tests>"; 
	bool s1, s2; 
	s1=c.tokenizeInputString(testString); 
	s2=c.parseTokenizedInput();
	REQUIRE(s1==true); 
	REQUIRE(s2==true); 
}  

TEST_CASE( "Test containsElementName", "[XMLParser]" ) { 
	XMLParser d; 
	string testString="<test><hello></hello></test>"; 
	d.tokenizeInputString(testString); 
	bool p0, p1, p2, p3; 
	p0=d.containsElementName("test"); 
	REQUIRE(p0==false); //Returns false if not yet parsed 
	bool s=d.parseTokenizedInput();
	REQUIRE(s==true);
	p1=d.containsElementName("test"); 
	REQUIRE(p1==true); 
	p2=d.containsElementName("hello"); 
	REQUIRE(p2==true); 
	p3=d.containsElementName("TEST"); 
	REQUIRE(p3==false); 
} 

TEST_CASE( "Test frequencyElementName", "[XMLParser]" ) { 
	XMLParser e; 
	string testString="<hot><cold><hot><HOT></HOT></hot></cold></hot>"; 
	e.tokenizeInputString(testString); 
	REQUIRE(e.frequencyElementName("hot")==0); 
	e.parseTokenizedInput(); 
	REQUIRE(e.frequencyElementName("temp")==0);  
	REQUIRE(e.frequencyElementName("hot")==4); 
	REQUIRE(e.frequencyElementName("cold")==2); 
	REQUIRE(e.frequencyElementName("HOT")==2); 
} 

TEST_CASE( "Test clear", "[XMLParser]" ) { 
	XMLParser f; 
	string testString="<hot></hot>"; 
	f.tokenizeInputString(testString); 
	f.parseTokenizedInput(); 
	REQUIRE(f.frequencyElementName("hot")==2); 
	f.clear(); 
	REQUIRE(f.frequencyElementName("hot")==0); 
} 

