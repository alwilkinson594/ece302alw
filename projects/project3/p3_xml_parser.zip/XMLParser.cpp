// Project 3 -- XML Parsing Project

/** XML parsing class implementation.
    @file XMLParser.cpp */

#include <string>
#include <assert.h>
#include "XMLParser.hpp"

// Default constructor makes a usable class instance 
XMLParser::XMLParser() { 
	parseStack=new Stack<std::string>(); //Stack of element tags 
	elementNameBag=new Bag<std::string>(); //Bag of element names
	tokenized=false;
}  // end default constructor

// Destructor deallocates all memory 
XMLParser::~XMLParser() {
	delete parseStack; 
	delete elementNameBag;  
	tokenizedInputVector.clear(); 
}  // end destructor

// Function to break string into tokenized vector 
bool XMLParser::tokenizeInputString(const std::string &inputString) {
	bool pos=true; //Assume true unless there is an issue 
	std::string pars=inputString; 
	char a=pars[0];
	if (a != '<') pos=false; //If first character is wrong, set invalid 
	int i=0; //Index currently being examined 
	int start; //Start of item in question 
	std::string invalidCharacters="!#$&'()*+,/;<=>?@[]\\^`{|}~%";
	std::string invalidFirsts="1234567890-. "; 
	std::string name=""; 
	StringTokenType tagtype; 
	while (i<pars.length() && pos==true) { //While there are characters left to examine 
		char b = pars[i];
		
		if (b=='<') { //If start of a new tag 
			if (name != "") { //If nested incorrectly, invalid 
				pos=false; 
				break; 
			} 
			i++; 
			start=i; 
		} 
		else if (i==start) { //If first character within tag (after <) 
			for (int k=0; k<invalidFirsts.length(); k++) { //Check each invalid first character 
				if (b==invalidFirsts[k]) { //If invalid for a first character 
					pos=false; 
					break; 
				} 
			}
			 
			//Check for and handle declarations or end tags
			if (b=='?') { //If DECLARATION 
				tagtype=DECLARATION; 
				i++; 
				b=pars[i];
				while (b !='?') { //Until end of declaration 
					for (int j=0; j<invalidCharacters.length(); j++) { //Check for invalid characters 
						if (b==invalidCharacters[j]) { 
							pos=false; 
							break; 
						} 
					}
					name+=b; 
					i++; 
					b=pars[i];
				} 
				i++;
				b=pars[i]; 
				if (b!='>') { //If invalid ending 
					pos=false; 
					break; 
				}
				i++; 
				b=pars[i]; 
			} //end checking for declarations 
			else if (b=='/') { //If start of END_TAG  	
				tagtype=END_TAG; 
				i++;
				b=pars[i]; 
				for (int j=0; j<invalidFirsts.length(); j++) { //Invalid starting characters 
					if (b==invalidFirsts[j]) { 
						pos=false; 
						break; 
					} 
				} 
				while (b != '>') { 
					if (b==' ') { //No whitespace allowed in end tags 
						pos=false; 
						break; 
					} 
					for (int j=0; j<invalidCharacters.length(); j++) { //Invalid
						if (b==invalidCharacters[j]) {
							pos=false; 
							break; 
						} 
					} 
					name+=b;
					i++; 
					b=pars[i];
				}
			} //End checking for end tags 
			else { //Start or empty tags 
				//Make sure first character is valid, but don't change yet if it is 
				for (int j=0; j<invalidFirsts.length(); j++) { 
					if (b==invalidFirsts[j]) { 
						pos=false;
						break; 
					} 
				} 
				while (b!= ' ' && b!='/' && b!='>') { //While not whitespace (anything after whitespace is ignored, or / or > meaning end of name, add name as long as valid 
					for (int j=0; j<invalidCharacters.length(); j++) { 
						if (b==invalidCharacters[j]) { 
							pos=false;
							break; 
						} 
					} 
					name+=b; 
					i++; 
					b=pars[i];
				} 
				if (b=='/') { //Empty tag 
					tagtype=EMPTY_TAG; 
					i++; 
					b=pars[i];
					if (b!='>') { 
						pos=false; 
						break; 
					} 
					i++; 
					b=pars[i];
				}
				else if (b=='>') { //Start tag 
					tagtype=START_TAG; 
					i++; 
					b=pars[i];
				} 
				else if (b==' ') { //Whitespace before attributes 
					i++;
					b=pars[i]; 
					while(b!='>' && b!='/') { 
						for (int j=0; j<invalidCharacters.length(); j++) { 
							if (b==invalidCharacters[j]) { 
								pos=false; 
								break; 
							} 
						} 
						i++; 
						b=pars[i];
					} 
					if (b=='/') { //Empty tag 
						tagtype=EMPTY_TAG; 
						i++;
						b=pars[i]; 
						if (b!='>') { //Invalid 
							pos=false;
							break; 
						} 
						i++; 
						b=pars[i];
					} 
					else { //Start tag 
						tagtype=START_TAG; 
						i++; 
						b=pars[i];
					} 
				} 
				else { //Invalid tag 
					pos=false; 
					break; 
				} 
			} //End start and empty tags 
			TokenStruct t; 
			t.tokenString=name; 
			name="";
			t.tokenType=tagtype;
			tokenizedInputVector.push_back(t); 
		} //End parsing tags 
		else i++; //Skip through content    	
	} //End loop through input string 
	if (pos==false) { 
		clear(); 
		return false;
	} 
	return true;
}  // end


// Check if nested correctly 
bool XMLParser::parseTokenizedInput() {
	int num=tokenizedInputVector.size(); 
	for (int i=0; i<num; i++) { //For each element in the vector, 
		TokenStruct tok=tokenizedInputVector.at(i); //Get the item 
		StringTokenType toktyp=tok.tokenType; //Get the tag type 
		std::string toknam=tok.tokenString; //Get the tag name 
		if (toktyp==START_TAG) { //Put start tags on stack 
			parseStack->push(toknam); 
		} 
		else if (toktyp==END_TAG) { 
			std::string tok2; 
			tok2=parseStack->peek(); 
			if (tok2==toknam) bool b=parseStack->pop(); //Remove from stack if correct match
			else return false; //If not nested properly, return false 
		} 
		else if (toktyp==DECLARATION || toktyp==EMPTY_TAG) {} //Ignore declaractions and empty tags, they don't have to line up with anything 
		else return false; //General default 
	}
	tokenized=true; 
	return true; 
}

// Clear all internal data 
void XMLParser::clear() {
	elementNameBag->clear(); 
	parseStack->clear(); 
	tokenizedInputVector.clear(); 
	tokenized=false; 
}

// Delete and remake vector, then return new vector 
vector<TokenStruct> XMLParser::returnTokenizedInput() const {
	std::vector<TokenStruct> v; 
	int num=tokenizedInputVector.size(); 
	for (int i=0; i<num; i++) v.push_back(tokenizedInputVector[i]);
	return v;
}

// Check if an element name is present 
bool XMLParser::containsElementName(const std::string &inputString) const {
	elementNameBag->clear(); 
	if (tokenized==false) return false; //Only test if successfully parsed 
	int num=tokenizedInputVector.size(); 
	for (int i=0; i<num; i++) { //Add each element name to the bag 
		TokenStruct t=tokenizedInputVector.at(i); 
		std::string s=t.tokenString; 
		elementNameBag->add(s); 
	} 
	std::string s=inputString; 
	bool pres=elementNameBag->contains(s); //Check if element name is present 
	return pres; //Return false if not present or not tokenized 
}

// Check how many times an element name is present 
int XMLParser::frequencyElementName(const std::string &inputString) const {
	elementNameBag->clear();
	if (tokenized==false) return 0; 
	int num=tokenizedInputVector.size(); 
	int freq=0;
	for (int i=0; i<num; i++) { //Add each element name to the bag 
		TokenStruct t=tokenizedInputVector.at(i); 
		std::string s=t.tokenString; 
		elementNameBag->add(s); 
	} 
	freq=elementNameBag->getFrequencyOf(inputString); 
	return freq; //Return the number of times the element appears 
}

