//  Adapated from Frank M. Carrano and Timothy M. Henry.

/** ADT Stack implementation.
    @file Stack.cpp */

#include <iostream>
#include <cstddef>
#include "Stack.hpp"
#include "Node.hpp"


//Default Constructor 
template<class ItemType> Stack<ItemType>::Stack() { 
	stackSize=0; //Initialize size of empty stack 
	headPtr=nullptr; 
}  // end default constructor


//Destructor 
template<class ItemType> Stack<ItemType>::~Stack() {
	while (isEmpty()==false) pop(); 
}  // end destructor


//Check if stack is empty 
template<class ItemType> bool Stack<ItemType>::isEmpty() const {
	if (stackSize==0) return true;
	else return false; 
}  // end isEmpty


//Check size of stack 
template<class ItemType> int Stack<ItemType>::size() const {
	return stackSize;
}  // end size


//Add a new item to the stack and increment the size to include it 
template<class ItemType> bool Stack<ItemType>::push(const ItemType& newItem) {
	Node<ItemType>* newNode = new Node<ItemType> (newItem, headPtr); 
	headPtr=newNode; 
	newNode=nullptr; 
	stackSize++;  
	return true;
}  // end push


//Look at top item on stack 
template<class ItemType>ItemType Stack<ItemType>::peek() const throw(logic_error) {
	ItemType returnItem;
	if (stackSize==0) throw "e"; 
	returnItem=headPtr->getItem(); 
	return returnItem;
}  // end peek


//Remove top item from stack and decrement size to exclude it 
template<class ItemType>bool Stack<ItemType>::pop() {
	if (stackSize==0) return false; 
	Node<ItemType>* node=headPtr; 
	headPtr=headPtr->getNext(); 
	node->setNext(nullptr); 
	delete node; 
	node=nullptr; 
	stackSize--;
	return true;
}  // end pop


//Remove all items from the stack  
template<class ItemType> void Stack<ItemType>::clear() {
	while (stackSize!=0) pop(); 
}  // end clear

