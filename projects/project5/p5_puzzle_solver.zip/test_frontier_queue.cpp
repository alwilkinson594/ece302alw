#define CATCH_CONFIG_MAIN
#include "catch.hpp"
#include "frontier_queue.hpp"

// TODO implement your tests here
// note you can use any supported type for the value type T
// including the Puzzle type as in the solver code

TEST_CASE( "Creation Test", "[frontier_queue]" ) { 
	frontier_queue<int> a; 
	REQUIRE(a.empty()==true); 
}

TEST_CASE( "Add Test", "[frontier_queue]" ) { 
	frontier_queue<int> b; 
	REQUIRE(b.empty()==true); 
	b.push(3, 1, 1); 
	REQUIRE(b.empty()==false); 
	b.push(5,6,2); 
	REQUIRE(b.empty()==false); 
	
	//Add something with the same f and path cost  
	b.push(4,1,1); 
	REQUIRE(b.contains(3)==true); 
	REQUIRE(b.contains(4)==true); 
	
	//Add something with the same value
	b.push(5, 4, 2); 
	REQUIRE(b.contains(5)==true); 
} 

TEST_CASE( "Remove Test", "[frontier_queue]" ) { 
	frontier_queue<int> c; 
	REQUIRE(c.empty()==true); 
	c.push(4,6,1); 
	REQUIRE(c.empty()==false); 
	c.pop(); 
	REQUIRE(c.empty()==true); 
	c.push(2,1,1); 
	c.push(4,8,6); 
	c.pop(); 
	REQUIRE(c.empty()==false); 
	c.pop(); 
	REQUIRE(c.empty()==true); 
} 

TEST_CASE( "Contains Test", "[frontier_queue]") {
	frontier_queue<int> d; 
	REQUIRE(d.empty()==true); 
	REQUIRE(d.contains(3)==false); 
	d.push(2,5,2); 
	REQUIRE(d.contains(3)==false); 
	d.push(3,7,4); 
	REQUIRE(d.contains(3)==true); 
	REQUIRE(d.contains(2)==true); 
	d.pop(); 
	REQUIRE(d.contains(3)==false); 
	REQUIRE(d.contains(2)==true); 
	d.pop(); 
	REQUIRE(d.contains(2)==false); 
} 

TEST_CASE( "Add Test with Many Values", "[frontier_queue]") { 
	frontier_queue<int> e; 
	REQUIRE(e.empty()==true); 
	for (int i=0; i<100; i++) { 
		e.push(i, i, i); 
		REQUIRE(e.empty()==false); 
		REQUIRE(e.contains(i)==true); 
	} 
	for (int i=0; i<100; i++) {
		REQUIRE(e.empty()==false); 
		e.pop();  
	} 
	REQUIRE(e.empty()==true); 
} 

