#define CATCH_CONFIG_MAIN
#define CATCH_CONFIG_COLOUR_NONE
#include "catch.hpp"
#include "FindPalindrome.hpp"

// There should be at least one test per FindPalindrome method

TEST_CASE("Test FindPalindrome add for non-allowable words","[FindPalindrome]") {
	INFO("Add a single non-allowable word");
	FindPalindrome b;
	REQUIRE(b.add("kayak1")==false);
	
	INFO("Add a vector with a non-allowable word"); 
	std::vector<std::string> vec;
	vec.push_back("kayak");
	vec.push_back("al;sgh"); 
	REQUIRE(b.add(vec)==false); 
	
	//2 assertions in function, 2 so far
}

TEST_CASE("Test FindPalindrome add for allowable words","[FindPalindrome]") {
	INFO("Add a single allowable word"); 
	FindPalindrome a;
	REQUIRE(a.number()==0);
	REQUIRE(a.add("dog")==true); 
	INFO("Add a vector of allowable words"); 
	std::vector<std::string> vec;
	vec.push_back("salad");
	vec.push_back("alsgh"); 
	REQUIRE(a.add(vec)==true); 
	
	//3 assertions in function, 5 so far
} 

TEST_CASE("Test FindPalindrome number", "[FindPalindrome]") {
	INFO("Test combinations of palindromes and not palindromes"); 
	FindPalindrome c;
	REQUIRE(c.number()==0); 
	REQUIRE(c.add("kak")==true);
	REQUIRE(c.number()==1);
	REQUIRE(c.add("ab")==true);
	REQUIRE(c.number()==0); 
	REQUIRE(c.add("ba")==true); 
	REQUIRE(c.number()==2); 
	
	//7 assertions in function, 12 so far 
} 

TEST_CASE("Test FindPalindrome clear", "[FindPalindrome]") {
	INFO("Test clear function after making a palindrome"); 
	FindPalindrome d;
	std::vector<std::string> vec;
	vec.push_back("cat");
	vec.push_back("dod");
	vec.push_back("tac"); 
	REQUIRE(d.add(vec)==true); 
	REQUIRE(d.number()==2);
	d.clear();
	REQUIRE(d.number()==0); 
	
	//3 assertions in function, 15 so far
} 

TEST_CASE("Test cut test1 function", "[FindPalindrome]") {
	INFO("Test cut test 1"); 
	FindPalindrome e;
	std::vector<std::string> vec1; 
	vec1.push_back("cat");
	vec1.push_back("dod");
	vec1.push_back("tac");
	REQUIRE(e.cutTest1(vec1)==true); 
	vec1.push_back("bbe"); 
	REQUIRE(e.cutTest1(vec1)==false);
	
	//2 assertions in function, 17 so far 
} 

TEST_CASE("Test cut test 2 function", "[FindPalindrome]") {
	INFO("Test cut test 2 function"); 
	FindPalindrome f;
	std::vector<std::string> vec1; 
	vec1.push_back("cat");
	vec1.push_back("dod");
	vec1.push_back("tac");
	vec1.push_back("bbe"); 
	std::vector<std::string> vec2;
	INFO("Test cut test 2"); 
	vec2.push_back("cat"); 
	vec2.push_back("dod");
	vec2.push_back("tac");
	vec2.push_back("bb"); 
	REQUIRE(f.cutTest2(vec1, vec2)==true); 
	vec2.push_back("f"); 
	REQUIRE(f.cutTest2(vec1, vec2)==false); 
	
	//2 assertions in function, 19 so far 
} 

TEST_CASE("Test to vector function", "[FindPalindrome]") {
	INFO("Test toVector function"); 
	FindPalindrome g;
	g.add("kayak"); 
	std::vector<std::vector<std::string>> vecvec;
	std::vector<std::string> vec;
	vec.push_back("kayak");
	vecvec.push_back(vec);
	REQUIRE(g.number()==1);
	REQUIRE(g.toVector()==vecvec); 
	
	//1 assertion in function, 20 so far
} 

