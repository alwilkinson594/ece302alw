#include <string>
#include <vector>
#include <iostream>
#include <locale> 
#include "FindPalindrome.hpp"

using namespace std;

//------------------- HELPER FUNCTIONS -----------------------------------------

// non-class helper functions go here, should be declared as "static" so that
// their scope is limited

// helper function to convert string to lower case
static void convertToLowerCase(string & value)
{
	locale loc;
	for (int i=0; i<value.size(); i++) {
		value[i] = tolower(value[i],loc);
	}
}

//------------------- PRIVATE CLASS METHODS ------------------------------------

// private recursive function. Must use this signature! 
//Find all possible palindromes.  
void FindPalindrome::recursiveFindPalindromes(vector<string> candidateStringVector, vector<string> currentStringVector) { 
	int numLeft=currentStringVector.size(); 
	if (numLeft==1) { //Base case - only one option 
		if (numWords!=1) candidateStringVector.push_back(currentStringVector[0]); 
		//See if it is a palindrome 
		bool pos=isPalindrome(candidateStringVector); 
		if (pos==true) {
			//If it is new, add it 
			bool repeat=false;
			for (int i=0; i<numPals; i++) { 
				if (pals[i]==candidateStringVector) repeat=true;
			} 
			if (repeat==false) {
				pals.push_back(candidateStringVector); 
				numPals++; 
			} 
		} 
	} 
	else { //Recursive section 
		if (numLeft==numWords) { //If first loop 
			for (int i=0; i<numWords; i++) { //For each possible first value 
				//Make the new vectors 
				std::vector<std::string> candidate;
				candidate.push_back(currentStringVector[i]);
				std::vector<std::string> current;
				for (int j=0; j<numWords; j++) {
					if (j!=i) current.push_back(currentStringVector[j]); 
				} 
				//Call recursively 
				recursiveFindPalindromes(candidate, current); 
			} 
		} 
		else { //For middle loops 
			for (int i=0; i<numLeft; i++) {
				//Make new vectors 
				std::vector<std::string> candidate;
				for (int j=0; j<candidateStringVector.size(); j++) candidate.push_back(candidateStringVector[j]); 
				candidate.push_back(currentStringVector[i]); 
				std::vector<std::string> current; 
				for (int j=0; j<numLeft; j++) {
					if (j!=i) current.push_back(currentStringVector[j]); 
				} 
				//Call recursively 
				recursiveFindPalindromes(candidate, current); 
			}
		}
	} 	
}

// private function to determine if a string is a palindrome (given, you
// may change this if you want)
bool FindPalindrome::isPalindrome(vector<string> tester) const {
	int words=tester.size();
	std::string phrase;
	for (int i=0; i<words; i++) phrase+=tester[i];
	int letters=phrase.length(); 
	convertToLowerCase(phrase); 
	for (int i=0; i<letters/2; i++) {
		if (phrase[i]!=phrase[letters-i-1]) return false; 
	} 
	return true;
}

//------------------- PUBLIC CLASS METHODS -------------------------------------



//Constructor and destructor
FindPalindrome::FindPalindrome() { //Default constructor 
	vec.clear(); //Make sure the vector is empty 
	numWords=0; //There are no words yet 
	//There are no combinations of words or palindromes present yet 
	pals.clear();
	numPals=0; 
}

FindPalindrome::~FindPalindrome() { //Destructor 
	//No words, combinations, or palindromes should be left 
	vec.clear(); 
	pals.clear();
	//No words or palindromes  
	numWords=0;
	numPals=0;
} 



//Basic functions 
int FindPalindrome::number() const { //Get the number of palindromes 
	return numPals;
}

void FindPalindrome::clear() { //Clear all words and sentences 
	//Clear the vectors 
	vec.clear();
	pals.clear();
	//Zero the words 
	numWords=0;
	numPals=0; 
}


//This test requires that there be an even number of items of each character, with one odd one for an odd length string 
bool FindPalindrome::cutTest1(const vector<string> & stringVector) {
	bool pos; //Return value 
	
	int letters[26]; //Hold a count of how many times each letter appears 
	for (int i=0; i<26; i++) letters[i]=0; //Zero to start 
	
	for (int i=0; i<stringVector.size(); i++) { //For each word, count the amount of times each letter appears 
		string word=stringVector[i]; 
		int len=word.length(); 
		for (int j=0; j<len; j++) {
			switch(word[j]) { 
				case 'a': 
				case 'A': 
					letters[0]++;
					break;
				case 'b':
				case 'B':
					letters[1]++;
					break;
				case 'c':
				case 'C':
					letters[2]++;
					break;
				case 'd':
				case 'D': 
					letters[3]++;
					break;
				case 'e':
				case 'E':
					letters[4]++;
					break;
				case 'f':
				case 'F':
					letters[5]++;
					break;
				case 'g': 
				case 'G': 
					letters[6]++;
					break;
				case 'h':
				case 'H':
					letters[7]++;
					break;
				case 'i':
				case 'I':
					letters[8]++;
					break;
				case 'j':
				case 'J': 
					letters[9]++;
					break;
				case 'k':
				case 'K':
					letters[10]++;
					break;
				case 'l':
				case 'L':
					letters[11]++;
					break;
				case 'm': 
				case 'M': 
					letters[12]++;
					break;
				case 'n':
				case 'N':
					letters[13]++;
					break;
				case 'o':
				case 'O':
					letters[14]++;
					break;
				case 'p':
				case 'P': 
					letters[15]++;
					break;
				case 'q':
				case 'Q':
					letters[16]++;
					break;
				case 'r':
				case 'R':
					letters[17]++;
					break;
				case 's':
				case 'S':
					letters[18]++;
					break;
				case 't':
				case 'T':
					letters[19]++;
					break;
				case 'u':
				case 'U':
					letters[20]++;
					break;
				case 'v':
				case 'V':
					letters[21]++;
					break;
				case 'w':
				case 'W':
					letters[22]++;
					break; 
				case 'x':
				case 'X':
					letters[23]++;
					break;
				case 'y':
				case 'Y':
					letters[24]++;
					break;
				case 'z':
				case 'Z': 
					letters[25]++;
					break;
			} //End switch case 
		} //End word for loop 
	} //End vector for loop 
	
	int numLets=0; //Find the total number of letters 
	int even=0; //Count the even words 
	int odd=0; //Count the odd words 
	
	for (int i=0; i<26; i++) { //Check how many letters appear an even or odd number of times 
		numLets+=letters[i]; //Count the letters 
		if (letters[i]%2==0) even++;
		else odd++; 
	} 
	
	if (numLets%2==0) { //If the total number of letters is even, all letters must appear an even number of times 
		if (odd==0) pos=true;
		else pos=false; 
	} 
	else { //If the total number of letters is odd, one letter must appear an odd number of times and the rest must be even 
		if (odd==1) pos=true; 
		else pos=false;
	} 
	
	return pos; //Return boolean 
}



//This test requires that each half of a string must have the same values 
bool FindPalindrome::cutTest2(const vector<string> & stringVector1, const vector<string> & stringVector2) { 
	//Get the number of characters in each vector and put vectors into strings 
	int num1=0;
	string s1;
	for (int i=0; i<stringVector1.size(); i++) {
		std::string word=stringVector1[i]; 
		num1+=word.length(); 
		s1+=word;
	} 
	int num2=0;
	string s2;
	for (int i=0; i<stringVector2.size(); i++) {
		std::string word=stringVector2[i]; 
		num2+=word.length(); 
		s2+=word;
	} 
	
	//Declare strings to hold each vector's contents 
	if (num1<num2) { //If the first is shorter 
		for (int i=0; i<num1; i++) { //For each of the shorter 
			bool pres=false; //Track if it was there 
			for (int j=0; j<num2; j++) { //Compare to the longer 
				if (s1[i]==s2[j]) { //If it is there 
					s2[j]='-'; //Set to non-letter to avoid reuse 
					pres=true; //Mark present 
					j=num2+1; //Skip rest of loop 
				} 
			} 
			if (pres==false) return false; 
		} 
	} 
	else { //If the second is shorter 
		for (int i=0; i<num2; i++) { //For each of the shorter 
			bool pres=false; 
			for (int j=0; j<num1; j++) { //Compare to each of the longer 
				if (s2[i]==s1[j]) { //If present 
					s1[j]='-'; //Set to non-letter to avoid reuse 
					pres=true;
					j=num1+1; //Skip rest of loop 
				} 
			} 
			if (pres==false) return false; 
		}
	} 
	return true; //Return the boolean 
}

bool FindPalindrome::add(const string & value) { //Add a new string in 
	
	//Make sure the value is not a repeat 
	for (int i=0; i<numWords; i++) {
		if (value==vec[i]) return false; 
	} 
	if (checkString(value)==false) return false; //Check for invalid characters 
	
	//Add the new string 
	vec.push_back(value);
	numWords++;  
	
	pals.clear();
	numPals=0;
	recursiveFindPalindromes(vec, vec);
	 
	//Return boolean to show the string was added if it was valid  
	return true; 
}

bool FindPalindrome::add(const vector<string> & stringVector) { //Add multiple new strings in 
	//Check uniqueness of each string 
	int count=stringVector.size();
	for (int i=0; i<count; i++) {
		for (int j=0; j<numWords; j++) {
			if (stringVector[i]==vec[j]) return false;
		}
		if (checkString(stringVector[i])==false) return false;
	} 
	
	
	//Add the strings onto the vector 
	for (int i=0; i<count; i++) {
		vec.push_back(stringVector[i]);
		numWords++;
	} 
	
	//Redo palindrome tests 
	pals.clear();
	numPals=0; 
	recursiveFindPalindromes(vec, vec); 
	
	//Return boolean to show that it was added 
	return true;
}


//Function to check for invalid characters 
bool FindPalindrome::checkString(std::string tester) const {
	int a=tester.length(); 
	for (int i=0; i<a; i++) {
		switch(tester[i]) {
			case 'a':
			case 'A':
			case 'b':
			case 'B':
			case 'c':
			case 'C':
			case 'd':
			case 'D':
			case 'e':
			case 'E':
			case 'f':
			case 'F':
			case 'g':
			case 'G':
			case 'h':
			case 'H':
			case 'i':
			case 'I':
			case 'j':
			case 'J':
			case 'k':
			case 'K':
			case 'l':
			case 'L':
			case 'm':
			case 'M':
			case 'n':
			case 'N':
			case 'o':
			case 'O':
			case 'p':
			case 'P':
			case 'q':
			case 'Q':
			case 'r':
			case 'R':
			case 's':
			case 'S':
			case 't':
			case 'T':
			case 'u':
			case 'U':
			case 'v':
			case 'V':
			case 'w':
			case 'W':
			case 'x':
			case 'X':
			case 'y':
			case 'Y':
			case 'z':
			case 'Z':
				break;
			default: 
				return false; 
		} 
	}
	return true; //Return boolean 
}


//Function to return a vector containing a vector of strings for each palindrome 
vector< vector<string> > FindPalindrome::toVector() const {	
	return pals; //Return 
}

